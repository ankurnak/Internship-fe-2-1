import React from "react";

const About = () => {
  return (
    <div className="container mt-5">
      <div className="jumbotron">
        <p className="lead">
          This is React Contact Management System application with Routing using FireBase
        </p>
      </div>
    </div>
  );
};

export default About;
