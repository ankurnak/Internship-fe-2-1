import React from "react";

const Error = () => {
  return (
    <div className="container-fluid mt-5">
      <div className="jumbotron jumbotron-fluid">
        <div className="container">
          <h1 className="display-4">No Such Page Exist</h1>
        </div>
      </div>
    </div>
  );
};

export default Error;
